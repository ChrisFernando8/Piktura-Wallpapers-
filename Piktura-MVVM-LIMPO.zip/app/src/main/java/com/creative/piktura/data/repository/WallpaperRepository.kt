package com.creative.piktura.data.repository

import com.creative.piktura.data.model.Wallpaper

class WallpaperRepository {

    fun getWallpapers(): List<Wallpaper> {
        return listOf(
            Wallpaper("https://picsum.photos/800/1600"),
            Wallpaper("https://picsum.photos/801/1600"),
            Wallpaper("https://picsum.photos/802/1600")
        )
    }
}
