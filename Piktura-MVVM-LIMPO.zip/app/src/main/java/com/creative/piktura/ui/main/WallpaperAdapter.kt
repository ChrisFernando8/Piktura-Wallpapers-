package com.creative.piktura.ui.main

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.creative.piktura.data.model.Wallpaper
import com.creative.piktura.databinding.ItemWallpaperBinding

class WallpaperAdapter(
    private val onClick: (Wallpaper) -> Unit
) : ListAdapter<Wallpaper, WallpaperAdapter.VH>(Diff()) {

    class VH(val binding: ItemWallpaperBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding = ItemWallpaperBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return VH(binding)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = getItem(position)
        holder.binding.image.load(item.url)
        holder.itemView.setOnClickListener { onClick(item) }
    }

    class Diff : DiffUtil.ItemCallback<Wallpaper>() {
        override fun areItemsTheSame(a: Wallpaper, b: Wallpaper) = a.url == b.url
        override fun areContentsTheSame(a: Wallpaper, b: Wallpaper) = a == b
    }
}
