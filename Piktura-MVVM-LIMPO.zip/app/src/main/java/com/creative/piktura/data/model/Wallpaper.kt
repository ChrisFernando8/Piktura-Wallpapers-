package com.creative.piktura.data.model

data class Wallpaper(
    val url: String
)
